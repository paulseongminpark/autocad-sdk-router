﻿# CAD OS V1 Import Contract

- Status: PASS
- Version: CAD OS Layer v1.0
- Source branch: cados/cad-os-v1.0-release-freeze
- Source commit: 2d5902461d5f3479feb1d59e405d9e11eb40d53f
- Tests: 566 passed, 0 skipped
- Native build: PASS
- Raw command agent exposure: 0
- write_original default: disabled
- Original DWG modified: False

## Import Rules
- Consume operation surface from reports/operation_coverage_full_matrix.json.
- Expose only agent_exposed implemented operations.
- Keep raw_command risk operations non-agent-exposed.
- Do not enable write_original by default.
- Route DWG mutations through staged-copy/write_copy flows unless a future approved packet grants explicit original-write authority.
- Treat hard_blocked operations as unavailable with blocker evidence, not as missing implementation.
