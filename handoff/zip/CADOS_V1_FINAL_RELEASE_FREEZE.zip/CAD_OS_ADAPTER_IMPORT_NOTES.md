﻿# CAD OS Adapter Import Notes

Daedalus should import CAD OS Layer v1.0 from release branch cados/cad-os-v1.0-release-freeze at commit 2d5902461d5f3479feb1d59e405d9e11eb40d53f, not from dirty main.

## Source Surfaces

- Latest status: D:\dev\_ariadne\_daedalus\external\cad_os\cad_os_latest_status.json
- Capabilities: D:\dev\_ariadne\_daedalus\external\cad_os\CAD_OS_V1_CAPABILITIES.json
- Import contract: D:\dev\_ariadne\_daedalus\external\cad_os\CAD_OS_V1_IMPORT_CONTRACT.json
- Repo final report: D:\dev\99_tools\autocad-sdk-router_cados_v1_final\reports\release\CADOS_V1_FINAL.json

## Import Constraints

- Treat raw command operations as non-agent-exposed.
- Do not default any adapter to write_original.
- Use staged copies for DWG mutation flows unless a future approved packet grants explicit original-write authority.
- Preserve the 29 hardblocks as blocked until a future evidence packet supplies safe typed/staged/introspection/attended replacements.
