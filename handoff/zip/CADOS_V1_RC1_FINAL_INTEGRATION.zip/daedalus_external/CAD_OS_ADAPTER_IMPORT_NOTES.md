# CAD OS Adapter Import Notes

CAD OS v1 RC1 is available as a release-candidate handoff, not a pushed release.

- Branch: `cados/cad-os-v1-rc1`
- Main checkout was dirty and was not modified.
- Use `reports/latest_status.json` or Daedalus `cad_os_latest_status.json` for current counts.
- Direct live original writes remain forbidden; `live.apply_patch` is deprecated in favor of staged governor routes.
- Raw command and arbitrary `SendStringToExecute` surfaces are not agent-exposed.
- Zero-skip validation requires `CADOS_LIVE=1`, a canonical native build, and the tracked DWG fixture; ignored `runs/` artifacts can regenerate from tests.
