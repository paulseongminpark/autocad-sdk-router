﻿# CAD OS Adapter Import Notes

Daedalus should import CAD OS v1 RC1 from the release-candidate branch cados/cad-os-v1-rc1, not from dirty main.

## Source Surfaces

- Latest status: D:\dev\_ariadne\_daedalus\external\cad_os\cad_os_latest_status.json
- Capabilities: D:\dev\_ariadne\_daedalus\external\cad_os\CAD_OS_V1_CAPABILITIES.json
- RC summary: D:\dev\_ariadne\_daedalus\external\cad_os\CADOS_V1_RC1_SUMMARY.md
- Repo RC report: D:\dev\99_tools\autocad-sdk-router_cados_v1_rc1\reports\release\CADOS_V1_RC1.json

## Import Constraints

- Treat raw command operations as non-agent-exposed.
- Do not default any adapter to write_original.
- Use staged copies for DWG mutation flows unless a future approved packet grants explicit original-write authority.
- Preserve the 29 hardblocks as blocked until a future evidence packet supplies safe typed/staged/introspection/attended replacements.
